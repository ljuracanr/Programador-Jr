﻿Public Class Sub_Menu
    Public Property AccionM As String
End Class
