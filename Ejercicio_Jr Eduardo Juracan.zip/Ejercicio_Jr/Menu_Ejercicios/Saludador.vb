﻿Public Class Saludador

    Public Property Saludo As String
    Public Property Nombres As String
End Class
