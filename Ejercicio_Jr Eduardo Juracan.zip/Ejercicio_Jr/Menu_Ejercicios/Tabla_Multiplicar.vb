﻿Public Class Tabla_Multiplicar
    Public Property Numero_Tabla As Int64
End Class
